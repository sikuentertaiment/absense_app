const app = {
	absenbutton:find('#absen'),
	nik:find('#nik'),
	topLayer:find('#top_layer'),
	getWaktuUrl(){
		return 'http://localhost:3000/getwaktu';
	},
	olddataabsense:{},
	init(){
		this.loadOldNik();
		this.loadDataAbsense();
		this.absenseButtonInit();
	},
	loadDataAbsense(){
		const nik = localStorage.getItem(btoa('old_data_absense')) || null;
		if(nik)
			this.olddataabsense = JSON.parse(atob(nik));
		console.log(this.olddataabsense);
	},
	loadOldNik(){
		const nik = localStorage.getItem(btoa('nik_karyawan')) || null;
		if(nik)
			this.nik.value = atob(nik);
	},
	saveNikData(){
		localStorage.setItem(btoa('nik_karyawan'),btoa(this.nik.value));
	},
	absenseButtonInit(){
		this.absenbutton.onclick = ()=>{
			this.doAbsense();
		}
	},
	async doAbsense(){
		this.topLayer.show('block');
		if(!this.nik.value.length){
			this.topLayer.hide();
			return Swal.fire({
			  icon: "error",
			  title: "Oops...",
			  text: "Nik tidak boleh kosong!"
			});
		}
		const time_now = await this.getWaktu();
		if(time_now.valid){
			const nowday = new Date().toLocaleDateString();
			if(this.olddataabsense[nowday]){
				if(this.olddataabsense[nowday][time_now.time_label]){
					this.topLayer.hide();
					return Swal.fire({
						icon:'error',
						title:'Gagal',
						text:`Anda sudah absen ${time_now.time_label.toLowerCase()}!`
					})
				}
			}
		}
		this.saveNikData();
		const absense = await this.absense(this.nik.value);
		this.saveOldDataAbsense(absense.absen_time_label);
		this.topLayer.hide();
		return Swal.fire({
			icon:absense.valid ? 'success' : 'error',
			title:absense.valid ? 'Success' : 'Opps',
			text:absense.message
		})
	},
	getAbsenseUrl(nik){
		return `http://localhost:3000/absen?nik=${nik}`;
	},
	absense(nik){
		return new Promise((resolve,reject)=>{
			cOn.get({url:this.getAbsenseUrl(nik),onload(){
				const response = this.getJSONResponse();
				resolve(response);
			}})
		})
	},
	saveOldDataAbsense(param){
		const nowday = new Date().toLocaleDateString();
		if(!this.olddataabsense[nowday]){
			this.olddataabsense[nowday] = {};
		}
		this.olddataabsense[nowday][param] = true;
		localStorage.setItem(btoa('old_data_absense'),btoa(JSON.stringify(this.olddataabsense)));
	},
	getWaktu(){
		return new Promise((resolve,reject)=>{
			cOn.get({
				url:app.getWaktuUrl(),
				onload(){
					resolve(this.getJSONResponse());
				}
			})
		})
	}
}
app.init();